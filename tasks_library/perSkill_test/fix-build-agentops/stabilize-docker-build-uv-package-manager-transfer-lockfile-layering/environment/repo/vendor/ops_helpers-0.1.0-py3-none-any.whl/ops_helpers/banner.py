def build_banner(name: str) -> str:
    return f"digest::{name}"
