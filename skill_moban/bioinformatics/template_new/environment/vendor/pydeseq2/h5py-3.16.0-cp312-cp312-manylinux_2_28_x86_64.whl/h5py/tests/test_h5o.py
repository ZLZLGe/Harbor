import pytest

from .common import TestCase, make_name
from h5py import File


class SampleException(Exception):
    pass

def throwing(name, obj):
    raise SampleException(f"throwing exception for {name} {obj}")

class TestVisit(TestCase):
    def test_visit(self):
        fname = self.mktemp()
        fid = File(fname, 'w')
        fid.create_dataset(make_name(), (100,), dtype='uint8')
        with pytest.raises(SampleException, match='throwing exception'):
            fid.visititems(throwing)
        fid.close()
